from django.apps import AppConfig


class App1Config(AppConfig):
    name = 'app1'
